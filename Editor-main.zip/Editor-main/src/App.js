import "./App.css";
import CanvasPage from "./Components/Canvas";
function App() {
  return (
    <div className="App">
      <CanvasPage />
    </div>
  );
}
export default App;
