<template>
  <div>
    <b-navbar toggleable="lg" type="dark" variant="success">
      <img alt="Vue logo" src="@/assets/logo.png" width="50px" padding="30px" />
      <b-navbar-brand href="#"
        ><strong> Graphic Designer</strong></b-navbar-brand
      >
    </b-navbar>

    <b-row>
      <the-canvas></the-canvas>
    </b-row>
  </div>
</template>

<script>
import TheCanvas from "@/components/TheCanvas.vue";
export default {
  name: "App",
  components: { TheCanvas },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.button-class {
  margin: 5px;
  border: 3px;
}
</style>
