<template>
  <div>
    <b-row>
      <b-col>
        <div>
          <b-list-group horizontal type="button">
            <b-list-group-item @click="addText()" class="button-class">
              <b-icon-cursor-text></b-icon-cursor-text> Add Text
            </b-list-group-item>
          </b-list-group>
        </div>
      </b-col>
      <b-col>
        <strong>Properties</strong>
        <div id="text-controls">
          <div>
            <label for="font-family">
              Font family:
            </label>
            <select
              id="font-family"
              v-model="fontFamily"
              @change="changeFontFamily('fontFamily')"
              class="button-class"
            >
              <option v-for="(font, index) in fonts" :key="index" :value="font">
                {{ font }}
              </option>
            </select>

            <label for="font-size">
              Font Size:
            </label>
            <select
              id="font-size"
              v-model="font"
              @change="changeFontSize('fontSize')"
              class="button-class"
            >
              <option
                v-for="(font, index) in fontSize"
                :key="index"
                :value="font"
              >
                {{ font }}
              </option>
            </select>
          </div>

          <div>
            <button @click="editText('bold')" class="button-class">Bold</button>

            <button @click="editText('underline')" class="button-class">
              Underline
            </button>

            <button @click="editText('italic')" class="button-class">
              Italic
            </button>

            <label for="text-bg-color">Color:</label>
            <input
              type="color"
              v-model="fontColor"
              id="text-bg-color"
              @input="changeFontColor('fill')"
              size="5"
              class="button-class"
            />
          </div>
        </div>
      </b-col>
    </b-row>
  </div>
</template>

<script>
import { fabric } from "fabric";
export default {
  props: {
    data: {
      type: Object,
    },
  },
  data() {
    return {
      fonts: ["Delicious_500", "verdana", "arial", "Pacifico", "VT323"],
      fontSize: ["10", "20", "30", "40", "50", "60"],
      fontFamily: "Delicious_500",
      font: 10,
      fontColor: "#00000",
    };
  },

  methods: {
    addText() {
      let text = new fabric.Textbox("Tap and Type", {
        fontFamily: "Delicious_500",
        left: 100,
        top: 100,
      });

      this.$emit("addObjectOnCanvas", text);
    },
    editText(task) {
      this.$emit("setTextProperty", task);
    },
    changeFontFamily(category) {
      this.$emit("changeFontFamily", this.fontFamily, category);
    },
    changeFontColor(category) {
      this.$emit("changeFontFamily", this.fontColor, category);
    },
    changeFontSize(category) {
      this.$emit("changeFontFamily", this.font, category);
    },
  },
};
</script>
