<template>
  <b-row>
    <b-col>
      <div>
        <b-list-group horizontal type="button" class="rounded-pill">
          <b-list-group-item @click="addShape('circle')" class="button-class">
            <b-icon-circle></b-icon-circle> Circle
          </b-list-group-item>
          <b-list-group-item @click="addShape('square')" class="button-class">
            <b-icon-square></b-icon-square> Square
          </b-list-group-item>
          <b-list-group-item @click="addShape('triangle')" class="button-class">
            <b-icon-triangle></b-icon-triangle> Triangle
          </b-list-group-item>
          <b-list-group-item @click="addShape('ellipse')" class="button-class">
            <b-icon-circle></b-icon-circle> Ellipse
          </b-list-group-item>
        </b-list-group>
      </div>
    </b-col>
    <b-col>
      <strong>Shape Properties</strong>
      <div id="shape-controls">
        <b-col>
          <div>
            <label for="shape-bg-color">Fill Color:</label>
            <input
              type="color"
              v-model="shapeProperty"
              id="shape-bg-color"
              @input="changeShapeProperties('fill')"
              size="5"
              class="button-class"
            />
            <label for="text-bg-color">Border Color:</label>
            <input
              type="color"
              v-model="shapeProp"
              id="text-bg-color"
              @input="changeShapeProperties('stroke')"
              size="5"
              class="button-class"
            />
          </div>

          <div>
            <label for="font-size">
              Border Width:
            </label>
            <select
              id="font-size"
              v-model="border"
              @change="changeBorderWidth('strokeWidth')"
              class="button-class"
            >
              <option
                v-for="(border, index) in borderWidth"
                :key="index"
                :value="border"
              >
                {{ border }}
              </option>
            </select>
          </div>
        </b-col>
      </div>
    </b-col>
  </b-row>
</template>

<script>
export default {
  data() {
    return {
      shapeProperty: "",
      shapeProp: "",
      shapeBorderColor: "",
      border: 1,
      creator: null,
      borderWidth: [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        20,
      ],
    };
  },
  methods: {
    addShape(task) {
      this.$emit("addShapesToCanvas", task);
    },
    changeShapeProperties(task) {
      if (task === "stroke") {
        this.$emit("changeFontFamily", this.shapeProp, task);
      } else {
        this.$emit("changeFontFamily", this.shapeProperty, task);
      }
    },
    changeBorderWidth() {
      this.creater = "strokeWidth";
      this.$emit("changeFontFamily", this.border, this.creater);
    },
  },
};
</script>
