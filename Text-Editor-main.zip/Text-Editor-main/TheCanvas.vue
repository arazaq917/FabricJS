<template>
  <div>
    <b-row>
      <side-bar
        @addObjectOnCanvas="addObjectOnCanvas"
        @addShapesToCanvas="addShapesToCanvas"
        @setTextProperty="setTextProperty"
        @changeFontFamily="changeFontFamily"
        @drawingModeEnable="drawingModeEnable"
        @changeLineColor="changeLineColor"
        @changeLineWidth="changeLineWidth"
        :data="this.data"
      ></side-bar>
    </b-row>
    <b-row>
      <b-col>
        <b-button
          class="button-class"
          variant="outline-primary"
          @click="zoomInZoomOut('zoomin')"
          >Zoom In</b-button
        >
        <b-button
          class="button-class"
          variant="outline-primary"
          @click="zoomInZoomOut('zoomout')"
          >Zoom Out</b-button
        >
        <b-button
          class="button-class"
          variant="outline-primary"
          @click="downloadCanvas"
          >Download Canvas as PNG</b-button
        >
      </b-col>
      <b-col>
        <canvas
          id="canvas-id"
          style="border: solid 2px;"
          class="rounded"
        ></canvas>
      </b-col>
      <b-col>
        <div>
          <b-button
            class="button-class"
            variant="outline-primary"
            @click="clearCanvas"
            >Clear</b-button
          >
          <b-button
            class="button-class"
            variant="outline-primary"
            @click="retrieveLastState"
            >Undo
          </b-button>
        </div>
        <div>
          <b-button
            class="button-class"
            variant="outline-primary"
            @click="removeSelectedObject"
            >Remove Object</b-button
          >
        </div>
        <div>
          <b-button
            class="button-class"
            variant="outline-primary"
            @click="addRandomObjects"
            >Random Objects</b-button
          >
        </div>
      </b-col>
    </b-row>
  </div>
</template>

<script>
import { fabric } from "fabric";
import SideBar from "@/components/SideBar.vue";
export default {
  components: { SideBar },
  data() {
    return {
      canvas: null,
      activeObject: null,
      undoStack: [],
      canvasScale: 1,
      scaleFactor: 1.01,
      data: null,
    };
  },
  mounted() {
    this.canvas = new fabric.Canvas("canvas-id", {
      width: 900,
      height: 360,
    });
    window.Canvas = this.canvas;
    this.canvas.on("selection:created", (e) => {
      if (e.target !== null) {
        this.data = e.target;
        console.log("This is textbox");
      } else {
        console.log("shapes");
      }
    });

    this.canvas.on("selection:updated", (e) => {
      console.log(e.target);
      if (e.target.type === "textbox") {
        this.data = e.target;
        console.log("This is textbox");
      } else if (
        this.data.type === "circle" ||
        this.data.type === "rect" ||
        this.data.type === "triangle" ||
        this.data.type === "ellipse"
      ) {
        console.log("shapes");
      }
    });
  },
  methods: {
    addRandomObjects() {
      for (let index = 0; index < 5; index++) {
        let circle = new fabric.Circle({
          left: fabric.util.getRandomInt(25, this.canvas.get("width") - 25),
          top: fabric.util.getRandomInt(25, this.canvas.get("height") - 25),
          radius: 25,
          fill: "#00000",
          hasRotatingPoint: true,
        });
        this.canvas.add(circle);
        let triangle = new fabric.Triangle({
          left: fabric.util.getRandomInt(25, this.canvas.get("width") - 25),
          top: fabric.util.getRandomInt(25, this.canvas.get("height") - 25),
          width: 80,
          height: 80,
        });
        this.canvas.add(triangle);
      }
    },
    downloadCanvas() {
      let image = this.canvas.toDataURL().replace("image/png");
      var link = document.createElement("a");
      link.download = "my-image.png";
      link.href = image;
      link.click();
    },
    setTextProperty(task) {
      let activeObject = this.canvas.getActiveObject();
      if (activeObject instanceof fabric.Object) {
        switch (task) {
          case "bold": {
            let isBold = activeObject.fontWeight === "bold";
            if (isBold) {
              activeObject.set({ fontWeight: "normal" });
            } else {
              activeObject.set({ fontWeight: "bold" });
            }
            this.canvas.renderAll();
            break;
          }
          case "underline": {
            let isUnderLine = activeObject.underline;
            if (isUnderLine) {
              activeObject.set({ underline: false });
            } else {
              activeObject.set({ underline: true });
            }
            this.canvas.renderAll();
            break;
          }
          case "italic": {
            let isItalic = activeObject.fontStyle === "italic";
            if (isItalic) {
              activeObject.set({ fontStyle: "normal" });
            } else {
              activeObject.set({ fontStyle: "italic" });
            }
            this.canvas.renderAll();
            break;
          }
        }
      }
    },
    changeFontFamily(task, category) {
      let activeObject = this.canvas.getActiveObject();
      activeObject.set(category, task);
      this.canvas.requestRenderAll();
    },
    addNewState() {
      let canvasObject = this.canvas.toJSON();
      this.undoStack.push(JSON.stringify(canvasObject));
    },
    addShapesToCanvas(task) {
      if (task === "circle") {
        let circle = new fabric.Circle({
          radius: 40,
          fill: "#00000",
        });
        this.canvas.add(circle);
        this.canvas.centerObject(circle);
      } else if (task === "triangle") {
        let triangle = new fabric.Triangle({
          width: 80,
          height: 80,
        });
        this.canvas.add(triangle);
        this.canvas.centerObject(triangle);
      } else if (task === "square") {
        let rect = new fabric.Rect({
          width: 80,
          height: 80,
        });
        this.canvas.add(rect);
        this.canvas.centerObject(rect);
      } else if (task === "ellipse") {
        let ellipse = new fabric.Ellipse({
          top: 150,
          left: 10,
          rx: 75,
          ry: 50,
        });
        this.canvas.add(ellipse);
        this.canvas.centerObject(ellipse);
      }
    },
    clearCanvas() {
      this.addNewState();
      this.canvas.clear();
    },
    retrieveLastState() {
      var latestState = this.undoStack[this.undoStack.length - 1];
      var parsedJSON = JSON.parse(latestState);
      this.canvas.loadFromJSON(parsedJSON);
      this.canvas.renderAll();
    },

    addObjectOnCanvas(text) {
      this.canvas.add(text);
    },
    removeSelectedObject() {
      this.addNewState();
      let activeObject = this.canvas.getActiveObject();
      this.canvas.remove(activeObject);
    },
    drawingModeEnable(isDrawingEnable) {
      this.canvas.isDrawingMode = isDrawingEnable;
      this.canvas.renderAll();
    },
    changeLineColor(task) {
      this.canvas.freeDrawingBrush.color = task;
    },
    changeLineWidth(task) {
      this.canvas.freeDrawingBrush.width = parseInt(task, 10) || 1;
    },
    zoomInZoomOut(action) {
      if (action === "zoomin") {
        this.canvas.setZoom(this.canvas.getZoom() * 1.1);
      } else if (action === "zoomout") {
        this.canvas.setZoom(this.canvas.getZoom() / 1.1);
      }
      this.canvas.renderAll();
    },
  },
};
</script>
