<template>
  <div>
    <b-card no-body>
      <b-tabs pills card vertical>
        <b-tab title="Text" active @click="drawingModeDisable">
          <text-properties
            @addObjectOnCanvas="addObjectOnCanvas"
            @setTextProperty="setTextProperty"
            @changeFontFamily="changeFontFamily"
            :data="this.data"
          ></text-properties>
        </b-tab>

        <b-tab title="Shape" @click="drawingModeDisable">
          <shapes-tab
            @addShapesToCanvas="addShapesToCanvas"
            @changeFontFamily="changeFontFamily"
          ></shapes-tab>
        </b-tab>

        <b-tab title="Drawing" @click="drawingModeEnable">
          <the-drawing
            @changeLineColor="changeLineColor"
            @changeLineWidth="changeLineWidth"
          ></the-drawing>
        </b-tab>

        <b-tab title="Image" @click="drawingModeDisable">
          <p class="button-title">
            Image
          </p>
          <input id="my-img" type="file" accept="image/*" />
          <b-button @click="upLoadImage()" variant="success">Send</b-button>
        </b-tab>
      </b-tabs>
    </b-card>
  </div>
</template>
<script>
import TheDrawing from "@/components/TheDrawing.vue";
import { fabric } from "fabric";
import ShapesTab from "@/components/ShapesTab";
import TextProperties from "@/components/TextProperties.vue";
export default {
  props: {
    data: {
      type: Object,
    },
  },
  components: {
    ShapesTab,
    TextProperties,
    TheDrawing,
  },
  data() {
    return {
      task: "",
      isDrawingEnable: false,
    };
  },
  methods: {
    addShapesToCanvas(task) {
      this.task = task;
      this.$emit("addShapesToCanvas", this.task);
    },
    upLoadImage() {
      const reader = new FileReader();
      const inputElem = document.getElementById("my-img");
      const file = inputElem.files[0];

      reader.readAsDataURL(file);
      reader.addEventListener("load", () => {
        fabric.Image.fromURL(reader.result, (img) => {
          this.$emit("addObjectOnCanvas", img);
        });
      });
    },
    addObjectOnCanvas(task) {
      this.$emit("addObjectOnCanvas", task);
    },
    setTextProperty(task) {
      this.$emit("setTextProperty", task);
    },
    changeFontFamily(task, category) {
      this.$emit("changeFontFamily", task, category);
    },
    drawingModeEnable() {
      this.isDrawingEnable = true;
      if (this.isDrawingEnable) {
        this.$emit("drawingModeEnable", this.isDrawingEnable);
      }
    },
    drawingModeDisable() {
      this.isDrawingEnable = false;

      this.$emit("drawingModeEnable", this.isDrawingEnable);
    },
    changeLineColor(task) {
      this.$emit("changeLineColor", task);
    },
    changeLineWidth(task) {
      this.$emit("changeLineWidth", task);
    },
  },
};
</script>
