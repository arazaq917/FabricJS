<template>
  <div>
    <b-row>
      <b-col>
        <span>
          Drawing Content
        </span>
      </b-col>
      <b-col>
        <label for="text-bg-color">Line Color:</label>
        <input
          type="color"
          v-model="lineColor"
          id="text-bg-color"
          @input="changelineColor"
          size="3"
          class="button-class"
        />
        <label for="range-1">Line Width: </label>
        <b-form-input
          id="line-width"
          v-model="lineWidth"
          type="range"
          @input="changeLineWidth"
          min="1"
          max="100"
          step="1"
        >
        </b-form-input>
        <span class="mt-2">Value: {{ lineWidth }}</span>
      </b-col>
    </b-row>
  </div>
</template>
<script>
export default {
  data() {
    return {
      lineColor: "",
      lineWidth: 1,
    };
  },
  methods: {
    changelineColor() {
      this.$emit("changeLineColor", this.lineColor);
    },
    changeLineWidth() {
      this.$emit("changeLineWidth", this.lineWidth);
    },
  },
};
</script>
